function t1() {
    let age = parseInt(document.getElementById('age').value);
    let r = "";
    if (age >= 0 && age < 12) { r = "Дитина"; }
    else if (age >= 12 && age < 18) { r = "Підліток"; }
    else if (age >= 18 && age < 60) { r = "Дорослий"; }
    else if (age >= 60) { r = "Пенсіонер"; }
    else { r = "Помилка"; }
    document.getElementById('r1').innerText = r;
}

function t2() {
    let digit = parseInt(document.getElementById('digit').value);
    let r = "";
    switch (digit) {
        case 1: r = "!"; break;
        case 2: r = "@"; break;
        case 3: r = "#"; break;
        case 4: r = "$"; break;
        case 5: r = "%"; break;
        case 6: r = "^"; break;
        case 7: r = "&"; break;
        case 8: r = "*"; break;
        case 9: r = "("; break;
        case 0: r = ")"; break;
        default: r = "Помилка";
    }
    document.getElementById('r2').innerText = r;
}

function t3() {
    let n = parseInt(document.getElementById('num3').value);
    let c3 = n % 10;
    let c2 = Math.floor((n / 10) % 10);
    let c1 = Math.floor(n / 100);
    document.getElementById('r3').innerText = (c1 === c2 || c2 === c3 || c1 === c3) ? "Є однакові цифри" : "Усі цифри різні";
}

function t4() {
    let y = parseInt(document.getElementById('year').value);
    let isLeap = (y % 400 === 0) || (y % 4 === 0 && y % 100 !== 0);
    document.getElementById('r4').innerText = isLeap ? "Високосний" : "Не високосний";
}

function t5() {
    let n = parseInt(document.getElementById('num5').value);
    let d1 = Math.floor(n / 10000);
    let d2 = Math.floor((n / 1000) % 10);
    let d4 = Math.floor((n / 10) % 10);
    let d5 = n % 10;
    document.getElementById('r5').innerText = (d1 === d5 && d2 === d4) ? "Паліндром" : "Не паліндром";
}

function t6() {
    let usd = parseFloat(document.getElementById('usd').value);
    let curr = document.getElementById('curr').value;
    let r = "";
    switch (curr) {
        case "EUR": r = (usd * 0.92) + " EUR"; break;
        case "UAH": r = (usd * 40.5) + " UAH"; break;
        case "AZN": r = (usd * 1.7) + " AZN"; break;
    }
    document.getElementById('r6').innerText = r;
}

function t7() {
    let s = parseFloat(document.getElementById('sum').value);
    let d = 0;
    if (s >= 200 && s < 300) { d = 0.03; }
    else if (s >= 300 && s < 500) { d = 0.05; }
    else if (s >= 500) { d = 0.07; }
    document.getElementById('r7').innerText = "До сплати: " + (s - (s * d));
}

function t8() {
    let cL = parseFloat(document.getElementById('cL').value);
    let sP = parseFloat(document.getElementById('sP').value);
    document.getElementById('r8').innerText = ((cL / Math.PI) <= (sP / 4)) ? "Поміститься" : "Не поміститься";
}

function t9() {
    let s = 0;
    let q1 = document.getElementById('q1').value;
    if (q1 === "2" || q1.toLowerCase() === "київ") s += 2;
    let q2 = document.getElementById('q2').value;
    if (q2 === "1" || q2 === "6") s += 2;
    let q3 = document.getElementById('q3').value;
    if (q3 === "3" || q3.toLowerCase() === "c#") s += 2;
    document.getElementById('r9').innerText = "Балів: " + s;
}

function t10() {
    let day = parseInt(document.getElementById('d').value);
    let month = parseInt(document.getElementById('m').value);
    let year = parseInt(document.getElementById('y').value);
    let dim = 31;
    if (month === 4 || month === 6 || month === 9 || month === 11) { dim = 30; }
    else if (month === 2) {
        let leap = (year % 400 === 0) || (year % 4 === 0 && year % 100 !== 0);
        dim = leap ? 29 : 28;
    }
    day++;
    if (day > dim) {
        day = 1;
        month++;
        if (month > 12) {
            month = 1;
            year++;
        }
    }
    document.getElementById('r10').innerText = "Наступна дата: " + day + "." + month + "." + year;
}