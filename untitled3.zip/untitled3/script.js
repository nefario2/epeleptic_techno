document.addEventListener("DOMContentLoaded", function() {
    
    let links = document.querySelectorAll("#links-list a");
    links.forEach(link => {
        let href = link.getAttribute("href");
        if (href.startsWith("http://") || href.startsWith("https://")) {
            link.classList.add("external-link");
        }
    });

    let folders = document.querySelectorAll(".tree .folder");
    folders.forEach(folder => {
        folder.addEventListener("click", function() {
            this.classList.toggle("open");
        });
    });

    let bookItems = document.querySelectorAll("#books-list li");
    let lastClickedIndex = -1;

    bookItems.forEach((item, index) => {
        item.addEventListener("click", function(e) {
            if (!e.ctrlKey && !e.shiftKey) {
                bookItems.forEach(li => li.classList.remove("selected"));
                this.classList.add("selected");
            } else if (e.ctrlKey) {
                this.classList.toggle("selected");
            } else if (e.shiftKey && lastClickedIndex !== -1) {
                let start = Math.min(index, lastClickedIndex);
                let end = Math.max(index, lastClickedIndex);
                for (let i = start; i <= end; i++) {
                    bookItems[i].classList.add("selected");
                }
            }
            lastClickedIndex = index;
        });
    });

    let textView = document.getElementById("text-view");
    let textEdit = document.getElementById("text-edit");

    document.addEventListener("keydown", function(e) {
        if (e.ctrlKey && e.code === "KeyE") {
            e.preventDefault();
            if (textView.style.display !== "none") {
                textEdit.value = textView.innerText;
                textView.style.display = "none";
                textEdit.style.display = "block";
                textEdit.focus();
            }
        }
        if (e.ctrlKey && e.code === "KeyS") {
            e.preventDefault();
            if (textEdit.style.display === "block") {
                textView.innerText = textEdit.value;
                textEdit.style.display = "none";
                textView.style.display = "block";
            }
        }
    });

    let table = document.getElementById("sort-table");
    let headers = table.querySelectorAll("th");
    let tbody = table.querySelector("tbody");

    headers.forEach((header, index) => {
        header.addEventListener("click", function() {
            let type = this.getAttribute("data-type");
            let rows = Array.from(tbody.rows);

            rows.sort((rowA, rowB) => {
                let cellA = rowA.cells[index].innerText;
                let cellB = rowB.cells[index].innerText;

                if (type === "number") {
                    return parseFloat(cellA) - parseFloat(cellB);
                }
                return cellA.localeCompare(cellB);
            });

            tbody.append(...rows);
        });
    });

    let box = document.getElementById("resizable-box");
    let handle = document.getElementById("resize-handle");

    handle.addEventListener("mousedown", function(e) {
        e.preventDefault();
        window.addEventListener("mousemove", resize);
        window.addEventListener("mouseup", stopResize);
    });

    function resize(e) {
        let rect = box.getBoundingClientRect();
        box.style.width = (e.clientX - rect.left) + "px";
        box.style.height = (e.clientY - rect.top) + "px";
    }

    function stopResize() {
        window.removeEventListener("mousemove", resize);
        window.removeEventListener("mouseup", stopResize);
    }
});